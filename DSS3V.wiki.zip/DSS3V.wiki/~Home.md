Welcome to the Digital Soldering Station v3.0 VFD  wiki!
![dss3v01.jpg](https://raw.githubusercontent.com/74ls00/DSS3V/master/Documents/pic/dss3v01.jpg)
![dss3v02.jpg](https://raw.githubusercontent.com/74ls00/DSS3V/master/Documents/pic/dss3v02.jpg)
![dss3v03.jpg](https://raw.githubusercontent.com/74ls00/DSS3V/master/Documents/pic/dss3v03.jpg)

Гнездо непонятного назначения, подходит как розетка. Похоже применялся в телевизоре для звука или сетевого выключателя. Под usb и air сделать забыл, теперь нереально, да они и не нужны.
![dss3v04.jpg](https://raw.githubusercontent.com/74ls00/DSS3V/master/Documents/pic/dss3v04.jpg)

Переходник подогревателя, для утюга.
Терпопару запихнул под асбест посередине чугунных блинов. Утюг давно без регулятора, выдаёт градусов 400. 
Утюг используется только для ЛУТ когда плевок зашкварчит или бумага темнеть начнёт, похоже градусов 120. Со станцией пока не проверял на плате, на деревяшку тонер переносит.
![dss3v05.jpg](https://raw.githubusercontent.com/74ls00/DSS3V/master/Documents/pic/dss3v05.jpg)
![dss3v06.jpg](https://raw.githubusercontent.com/74ls00/DSS3V/master/Documents/pic/dss3v06.jpg)

Радиатор маловат, но менять не хочется, не часто пользуюсь.
![dss3v07.jpg](https://raw.githubusercontent.com/74ls00/DSS3V/master/Documents/pic/dss3v07.jpg)

Новый ide шлейф на столько бесполезен что годится только накальные обмотки мотать. Наматывал лак , но он сдирался об железо, пластик покрепче. Разобрать транс нереально, сматывал лишнее через щель.
![dss3v08.jpg](https://raw.githubusercontent.com/74ls00/DSS3V/master/Documents/pic/dss3v08.jpg)

Фоткал видеокамерой, она это делает плохо. Цвета светодиодов и индикаторов не правильные.
Индикация скорее синяя чем зелёная. Люминофор от светодиодного освещения 10вт за метр начинает светится, поэтому панель видно плохо.
Двойной светодиод вместо оранжевого видно жёлтым. Вторая половина яркий зелёный  реально светит намного слабее чем на фото.
Светодиодные шкалы жёлто зелёного цвета как зелёный люминофор цветного кинескопа.
![dss3v09.jpg](https://raw.githubusercontent.com/74ls00/DSS3V/master/Documents/pic/dss3v09.jpg)

Крепление от 32мм трубы. Верх обрезан чтоб не сильно зажимало. Боковой крючок срезан и воткнут в паз с другой стороны чтоб не было щели. Обклеено как и корпус винилом, но держится плохо, сдирается об острые края, да и полиэтилен липнет плохо.
У фена залил щели силиконом (что было) чтоб легче втыкать, чтоб не сдиралось обернул плёнкой.
Идея с плёнкой плохая, не выдерживает такие нагрузки.
![dss3v10.jpg](https://raw.githubusercontent.com/74ls00/DSS3V/master/Documents/pic/dss3v10.jpg)




