fuse_defs = {"LOW":{"bits":[],"options":[]}};create_interface();
