programmers = {avrstudio: {name : "AVR Studio", invert: true}, uniprof: {name: "Uniprof", invert: false}, ponyprog: {name: "PonyProg", invert: true}};
